package restaurinoPOS;

public class Bestellung //TODO
{
	boolean Preis;
	String bezeichnung;
	
	Bestellung [][] alleBestellungen = new Bestellung [6][6];
}
