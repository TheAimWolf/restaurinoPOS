package restaurinoPOS;

public class Person 
{
	String vorname, nachname;
	
	
	public Person(String vorname, String nachname)
	{
		this.nachname = vorname;
		this.nachname = nachname;
		
	}
	
	
	
	
	
	
	//getter und setter
	
	public String getName()
	{
		return vorname + " " + nachname;
	}
}
